---- OnCall I.P. Phone System (U.I. Demo) ----

This application for demonstrate the User Interface of OnCall I.P. phone system. It have removed all I.P. Phone functions.

To access the application, please follow the steps below:



1.  Type anything on the ��User Name�� and ��Password�� filed 

2.  Press login.

3.  Please feel free to play around.
